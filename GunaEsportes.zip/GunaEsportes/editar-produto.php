<!doctype html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link href="assets/css/admin.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="icon" href="img/logo-ifsp-removebg.png" type="image/x-icon">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">

  <title>GunaEsportes - Editar Produto</title>
</head>


<body>
<form action="admin.php" method="post" style= "margin-left:0;">
                <input type="submit" name="voltar" class="botao-cadastrar" value="voltar" style="display: block; margin-left: auto; margin-right: auto;" />
            </form>
  <main>
    <section class="container-admin-banner">
      <img src="img/separador.png" class="logo-admin" alt="">
      <h1>Editar Produto</h1>
      <img class="ornaments" src="assets/img/separador.png" alt="ornaments">
    </section>
    <section class="container-form">
      <?php
      require "conexao.php";
      $id = $_GET['id'];
      $sql = "select * from usuario where id = '$id'";
      $result = $conn->query($sql);
      $row = $result->fetch_assoc();
      ?>
      <div class="editarusuario">
      <form action="processar-editar-produto.php" method="POST" onsubmit="editarcadastro();" id="editarcadastro" enctype="multipart/form-data">>

        <label for="nome">Nome</label>
        <input type="text" id="nome" name="nome" placeholder="<?php echo $row['nome']; ?>" value="<?php echo $row['nome']; ?>" required>
<br><br>
        <label for="senha">senha</label>
        <input type="text" id="senha" name="senha" placeholder="<?php echo $row['senha']; ?>" value="<?php echo $row['senha']; ?>" required>
        <br><br>
        <label for="telefone">telefone</label>
        <input type="text" id="telefone" name="telefone" placeholder="<?php echo $row['telefone']; ?>" value="<?php echo $row['telefone']; ?>" required>
        <br><br>
        <label for="Email">email</label>
        <input type="text" id="email" name="email" placeholder="<?php echo $row['email']; ?>" value="<?php echo $row['email']; ?>" required>

        <?php $imagemfake = $row['imagem'];
               
        // Remove a parte "C:\fakepath\" do valor (apenas no caso de navegadores baseados em Windows)
        $imagem = basename($imagemfake);

        // Agora, $imagem conterá apenas o nome do arquivo, sem a parte "C:\fakepath\"
        ?>
        <label for="imagem">Envie uma nova imagem do produto ou mantenha a imagem atual: 
          <div class="container-foto">
            <img src="<?= $row['imagem']; ?>" alt="<?php echo $imagem; ?>" width="200">
          </div><?php echo $imagem; ?></label>
        <input type="file" name="imagem" accept="image/*" id="imagem" value="<?php echo $imagem;?>">


        <br><br>
        <input type="hidden" name="id" id="id" value="<?= $row['id']; ?>">
        </div>

        <input type="submit" name="editar" class="botao-cadastrar" value="Editar produto" />
      </form>

    </section>
  </main>
  

  <script>
    

    function editarProduto() {
      event.preventDefault(); // Impede o envio padrão do formulário
      // Pega o valor do campo de arquivo
      const fileInput = document.getElementById("imagem");
      const filePath = fileInput.value;

      // Remove a parte "C:\fakepath\" do valor
      const fileName = filePath.replace("C:\\fakepath\\", "");

      const nome = document.getElementById("nome").value;
      const senha = document.querySelector('input[name="tipo"]:checked').value;
      const telefone = document.getElementById("telefone").value;
      const email = document.getElementById("email").value;
      const imagem = document.getElementById("imagem").value;
      const id = document.getElementById("id").value;

      Swal.fire({
        title: "Confirme a edição do produto",
        html: `<strong>Nome:</strong> ${nome}<br>
           <strong>senha:</strong> ${senha}<br>
           <strong>telefone:</strong> ${telefone}<br>
           <strong>email:</strong> ${email}<br>
           <strong>Imagem:</strong> ${fileName}<br>`,
        showDenyButton: true,
        
        confirmButtonText: "Editar",
        denyButtonText: "Cancelar",

      }).then((result) => {
        if (result.isConfirmed) {
          // Se o usuário confirmar a edição, redirecione para outra página
          const url = `processar-editar-produto.php?nome=${nome}&senha=${senha}&telefone=${telefone}&email=${email}&id=${id}&imagem=${imagem}`;
          window.location.href = url;
        } else if (result.isDenied) {
          Swal.fire("Edição cancelada", "", "info");
        }
      });

      // Impede o envio do formulário
      return false;
    }
  </script>



  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-maskmoney/3.0.2/jquery.maskMoney.min.js" integrity="sha512-Rdk63VC+1UYzGSgd3u2iadi0joUrcwX0IWp2rTh6KXFoAmgOjRS99Vynz1lJPT8dLjvo6JZOqpAHJyfCEZ5KoA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

</body>

</html>