<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GunaEsportes</title>
<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">

  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Raleway:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
   
  <link href="assets/img/ICON DBE.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">



  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <link href="assets/css/main.css" rel="stylesheet">


</head>
<body>

<!-- ======= Header ======= -->
<section id="topbar" class="topbar d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:contact@example.com">InstitutoFederal@gmail.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+55 11 94759 3848</span></i>
      </div>
    </div>
  </section><!-- End Top Bar -->

  <header id="header" class="header d-flex align-items-center">

    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>GunaEsportes<span>.</span></h1>
      </a>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php">Início</a></li>
          <li><a href="index.php">Sobre</a></li>
          <li><a href="index.php">Comentários</a></li>
          <li><a href="index.php">Atletas</a></li>
          <li><a href="index.php">Notícias</a></li>
          <li><a href="index.php">Contribuição</a></li>
          <li><a href="index.php">Time</a></li>
        </ul>
        
        
      </nav><!-- .navbar -->

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

    </div>
  </header><!-- End Header -->
  <!-- End Header -->



    <!-- ======= Cadastro ======= -->

    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <section id="contact" class="contact">
          <div class="container" data-aos="fade-up">
    
            <div class="section-header">
              <img src="assets/img/Acessa ai.jpg" alt="" class="img-fluid">
              <br><br><br><br><br><br>
              <h1>Cadastro</h1>
              <p>Faça seu cadastro agora para receber as notícias mais recentes deste evento esportivo</p>
            </div>
              <div id="col-lg-8">
    
                <form action="forms/processar-cadastro.php" method="POST" enctype="multipart/form-data" role="form" class="php-email-form">
                  <label for="nome">Nome:</label>
                  <input type="text" class="form-control" id="nome" name="nome" placeholder="Exemplo: Seu nome" required><br><br>
          
                  <label for="email">Email:</label>
                  <input type="email" class="form-control" id="email" name="email" placeholder="Exemplo: user@gmail.com" required><br><br>

          
                  <label for="senha">Senha:</label>
                  <input type="password" class="form-control" id="senha" name="senha" placeholder="Exemplo: SenhaSegura123" required><br><br>


                  <label for="telefone">Telefone:</label>
                  <input type="text" class="form-control" id="telefone" name="telefone" placeholder="Exemplo: (99) 99999-9999" required><br><br>
          
                  <label for="imagem">Envie uma imagem do produto</label>
                  <input type="file" class="form-control" name="imagem" accept="image/*" id="imagem" placeholder="Envie uma imagem">

                  <br><br>
          



                  <input type="submit" name="cadastro" id="butao" value="Cadastrar usuario">
             <br><br><br>
                  <div class="text-center p-t-115">
                            <span class="txt1">
                                Já tem conta?
                            </span>

                            <a class="txt2" href="log.php">
                                Logue-se
                            </a>
                        </div>

                </form>
    
              </div>
              

        <!-- End Contact Form -->

        </div>

      </div>
    </section><!-- End Cadastro -->

















  <br><br><br><br><br>
    <br><br><br><br><br>

     <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

<div class="container">
  <div class="row gy-4">
    <div class="col-lg-5 col-md-12 footer-info">
      <a href="index.html" class="logo d-flex align-items-center">
        <span>GunaEsportes</span>
      </a>
      <p>Eai, se interessou pelo site? Gostou da iniciativa? Cadastre-se para não perder nenhuma novidade!</p>
    </div>

    <div class="col-lg-2 col-6 footer-links">
      <h4>Useful Links</h4>
      <ul>
        <li><a href="#">Início</a></li>
        <li><a href="#">Sobre</a></li>
        <li><a href="#contact ">Cadastro</a></li>
        <li><a href="#">Termos de serviço</a></li>
        <li><a href="#">Política de privacidade</a></li>
      </ul>
    </div>

    <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
      <h4>Nos contate!</h4>
      <p>
        Av. Salgado Filho, 3501 - Centro, Guarulhos - SP, 07115-000 <br><br>
        <strong>Phone:</strong> +55 11 94628 3947<br>
        <strong>Email:</strong> InstitutoFederal@gmail.com<br>
      </p>

    </div>

  </div>
</div>

<div class="container mt-4">
  <div class="copyright">
    &copy; Copyright <strong><span>GunaEsportes</span></strong>. All Rights Reserved
  </div>
  <div class="credits">
    <!-- All the links in the footer should remain intact. -->
    <!-- You can delete the links only if you purchased the pro version. -->
    <!-- Licensing information: https://bootstrapmade.com/license/ -->
    <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/impact-bootstrap-business-website-template/ -->
  </div>
</div>

</footer><!-- End Footer -->
<!-- End Footer -->




     <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</html>