CREATE DATABASE jif;
USE jif;

CREATE TABLE usuario ( id int 
auto_increment primary key,
  nome VARCHAR(255),
  email VARCHAR(255) PRIMARY KEY,
  senha VARCHAR(255),
  telefone VARCHAR(255),
  imagem VARCHAR(80) NOT NULL
);




INSERT INTO usuario (nome, email, senha, telefone) VALUES
('Borges', 'borges@gmail.com', '123', '555-1234', 'borges.png'),
('Bruna', 'bruna@gmail.com', '456', '555-5678', 'bruna.png');

 select * from usuario;

update usuario set imagem = concat("../img/",imagem);

 
DELETE FROM usuario;



