<?php
echo $row['imagem']; // Adicione isso para verificar o valor
?>