CREATE DATABASE jif;
USE jif;

CREATE TABLE usuario (
  nome VARCHAR(255),
  email VARCHAR(255) primary key,
  senha VARCHAR(255),
  telefone VARCHAR(255)
);

INSERT INTO usuario (nome, email, senha, telefone) VALUES
('Borges', 'borges@gmail.com', '123', '555-1234'),
('Bruna', 'bruna@gmail.com', '456', '555-5678');

 select * from usuario;