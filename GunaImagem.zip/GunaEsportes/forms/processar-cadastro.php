<?php
require_once "conexao.php";

// Obter os dados do formulário
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];
$telefone = $_POST["telefone"];

if (isset($_FILES["imagem"]) && $_FILES["imagem"]["error"] == 0) {
    $uploadDir = "img/"; // Diretório de destino
    $uploadFile = $uploadDir . basename($_FILES["imagem"]["name"]);
    $imagem = $uploadFile;

    // Move o arquivo para o diretório de destino
    if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $uploadFile)) {
        // Inserir os dados na tabela 'usuario'
        $sql = "INSERT INTO usuario (nome, email, senha, telefone, imagem) VALUES ('$nome', '$email', '$senha', '$telefone', '$imagem')";

        // Executar a consulta SQL
        if ($conn->query($sql) ===  TRUE) {
            header("Location:../cad-log.php");
            exit();
        } else {
            header("Location: cadastre.php?erro=2");
            exit();
        }
    } else {
        echo "Erro ao fazer o upload da imagem.";
    }
} else {
    echo "Erro: " . $_FILES["imagem"]["error"];
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
